# Testing positional Parameters
head $1
echo "..."
tail $1
