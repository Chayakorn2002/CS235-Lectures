date
echo "Logged in Users"
who
